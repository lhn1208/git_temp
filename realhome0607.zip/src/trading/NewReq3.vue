<script setup>
import { ref } from 'vue';
import './trading.css';
import Tab from '../common/Tab.vue';
import Step from '../components/Step.vue';
import RtContHeader from '../components/RtContHeader.vue';
import AgentIntro from '../agent/AgentIntro.vue';
const activeTab = ref('tab1');

const updateTab = (tab) => {
  activeTab.value = tab;
};
</script>
<template>
    <div>
        <Step linktoPrev="newReq2" linktoNext="newReq4" :prvBtShow="true" :nextBtShow="true" :step3="true"/>
        <div class="sub_content">
            <div class="divide request">
                 <!--left content-->
                 <div class="left_container h_add">
                    <div class="content">
                        <AgentIntro />
                        <Tab 
                            tabTit1="중개사 평점"
                            tabTit2="중개사무소 위치"
                            @updateTab="updateTab"
                        />
                        <div v-if="activeTab === 'tab1'">
                            탭111
                        </div>
                        <div v-if="activeTab === 'tab2'">
                            탭222
                        </div>
                    </div>
                </div>
                <!--//left content-->
                <aside class="right_container h_add">
                    <RtContHeader 
                        title="방문요청 매물"
                        totalCnt="10"
                        colorClass="grass"
                    />
                </aside>
            </div>
        </div>
    </div>
</template>