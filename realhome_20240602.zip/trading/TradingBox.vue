<script setup>
</script>
<template>
  <div class="trading_box">

  </div>
</template>