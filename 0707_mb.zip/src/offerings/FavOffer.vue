<script setup>
import ItemBox from '../components/ItemBox.vue'
import Header from '../common/Header.vue'
import './offerings.css'
</script>
<template>
<div>
  <Header title="최근 본 매물" link="/"/>
  <div class="items_wrap">
    <ItemBox 
        alt="매물 이미지1" 
        title="월세 5억1000/50" 
        info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
        type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
        addr="잠실주공1단지 104동잠실"
        :seen="true"
    />
    <ItemBox 
        alt="매물 이미지1" 
        title="월세 5억1000/50" 
        info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
        type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
        addr="잠실주공1단지 104동잠실"
        :dealEnd="true"
    />
    <ItemBox 
        alt="매물 이미지1" 
        title="월세 5억1000/50" 
        info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
        type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
        addr="잠실주공1단지 104동잠실"
    />
     <ItemBox 
        alt="매물 이미지1" 
        title="월세 5억1000/50" 
        info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
        type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
        addr="잠실주공1단지 104동잠실"
    />
  </div>
</div>
</template>