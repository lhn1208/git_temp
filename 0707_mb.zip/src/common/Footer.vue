<script setup>
  import { useRouter } from 'vue-router';
  import './common.css'
  const router = useRouter();
  const navigate = (link) => {
   if(link==='home'){
    router.push(`/`);
   }
  };
</script>
<template>
  <div class="footer">
     <ul class="footer_in">
        <li class="home"><a href="#" @click.prevent="navigate('home')">홈</a></li>
        <li class="map"><a href="#">지도</a></li>
        <li class="state"><a href="#">중개현황</a></li>
        <li class="alarm"><a href="#"><span class="num">3</span>알림</a></li>
        <li class="more"><a href="#">더보기</a></li>
     </ul>
  </div>
</template>
