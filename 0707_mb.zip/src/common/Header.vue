<script setup>
import { defineProps } from 'vue';
import { useRouter } from 'vue-router';
import './common.css'
const props = defineProps({
    title:String,
    link:String
});
const router = useRouter();
  const navigate = () => {
    if (props.link ==='/') {
    router.push(`/`);
   }else if (props.link) {
    router.push(`/${props.link}`);
   }
  };

</script>
<template>
  <header class="header">
    <button class="btn_prev" @click="navigate" >이전</button>
    <div class="header_in">
        <h1 class="h1_tite">{{title}}</h1>
    </div>
   
  </header>
</template>
