  <script setup>
  import { defineProps } from 'vue';
  const props = defineProps({
    title: String,
    titleClass:String,
    bg_Class:String,
    text:String,
    linkText:String,
    num:Number
  });
  </script>
  <template>
     <div class="box_wrap">
        <div :class="[bg_Class, 'box intro_box']">
          <strong :class="[titleClass, 'tit']">{{title}}<span v-if="num">(<em class="f_red">{{num}}</em>)</span></strong>
          <p v-html="text"></p>
        </div>
        <a class="link_box f_blue">{{linkText}}<span class="link_arr">바로가기</span></a>
      </div>
  </template> 