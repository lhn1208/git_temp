module.exports = {
   publicPath: '/vue_realhome/'
}