<script setup>
import {ref, nextTick, reactive} from 'vue'
const count = ref(0)
const state = reactive({count2 : 0})
const increment = async () => {
  count.value++;
  console.log('counter==>'+document.getElementById('counter').textContent);
 await nextTick()//업데이트 완료된 후
 console.log('counterupdated==>'+document.getElementById('counter').textContent);
}

</script>
<template>
  {{ console.log('templet실행') }}
  <div class="layout">
    <h1>This is an Reactivity  page</h1>
    <div>
      <!-- <button @click="count++">카운트증가</button> -->
      <button @click="increment">카운트증가</button>
      <div id="counter">{{ count }}</div>
      <hr>
      <button @click="state.count2++">카운트2 증가</button>
      <div>{{ state.count2 }}</div>
    </div>
  </div>
</template>

<style>
@media (min-width: 1024px) {
  /* .layout {
    min-height: 100vh;
     display: flex;
    align-items: center;
  } */
}
</style>
