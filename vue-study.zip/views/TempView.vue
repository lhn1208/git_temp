<script setup>

const pid=10;
const isButtonDisabled=true;
const objectOfAttrs = {
      id: 'container',
      class: 'wrapper'
    }
const number=20;
const ok=false;
const message="안녕하세요";
const id=30;
const sayHello = (msg) =>{
  alert(msg);
}
const url="http://www.google.com";
const attributeName='href';
const items=[
  {id:0, title:'html'},
  {id:1, title:'css'},
  {id:2, title:'java'},
]
const onSubmit=() =>{
  alert("제출되었습니다.");
}
</script>
<template>
  <div class="layout">
    <h1>This is an templet page</h1>
    <div>
      <hr>
      <h2>속성 바인딩</h2>
      <div :id="pid"></div>
      <h2>불리언 바인딩</h2>    
      <button :disabled="isButtonDisabled">버튼</button>
      <button :disabled="!isButtonDisabled">버튼</button>
      <h2>여러속성 바인딩</h2>
      <div v-bind="objectOfAttrs"></div>
      <h2>자바스크립트 표현식</h2>
      {{ number + 1 }}

      {{ ok ? '예' : '아니오' }}

      {{ message.split('').reverse().join('') }}

      <div :id="`list-${id}`"></div>
      <!-- <span :title="sayHello('Yeah')"> </span> -->
      <!-- <div>
        {{ sayHello('Yeah')   }}
      </div> -->
      <h2>디렉티브</h2>
      <a v-bind:href="url">구글</a><a :href="url">구글</a>
      <a v-bind:[attributeName]="url">...</a>
      <div v-for="item in items" :key="item.id" >
        {{ item.title }}
      </div>
      <h2>v-on</h2>
      <div>
        <button type="button" v-on:click="sayHello('Yeah')">버튼</button>
        <button type="button" @click="sayHello('Yeah')">버튼</button>
      </div>
      <form action=""  @submit.prevent="onSubmit">
          <button>제출</button>
      </form>
    </div>
  </div>
</template>

<style>
@media (min-width: 1024px) {
  .layout {
    min-height: 100vh;
    /*display: flex;
    align-items: center;*/
  }
}
</style>
