<script>
export default{
  data(){  
    return{
     parentLangs:'web',
     items:[
        {id:1, title:'HTML',desc:'HTML ...'},
        {id:2,title:'CSS',desc:'CSS ...'},
        {id:3,title:'Javascript',desc:'Javascript ...'}
     ],
     myObject : {
        title: 'Vue에서 목록을 작성하는 방법',
        author: '홍길동',
        publishedAt: '2016-04-10'
      },
      numbers :[1, 2, 3, 4, 5],
       sets : [
              [1, 2, 3, 4, 5],
              [6, 7, 8, 9, 10]
            ]

    }
  },
  computed: {
    evenNumbers () {
        return this.numbers.filter((n) => n % 2 === 0)
      }
    },
    methods :{
        even(numbers2) {
          return numbers2.filter((number) => number % 2 === 0)
        }
    }
}
</script>
<template>
  <div class="about">
    <h1>This is an List page</h1>
    <ul>
      <li v-for="(item, index) in items" :key="item.id">
       {{ parentLangs }}: {{index}}-{{ item.title }}
      </li>
    </ul>
    <h2>객체</h2>
    <ul>
      <li v-for="value in myObject">
        {{ value }}
      </li>
    </ul>
    <span v-for="n in 10">{{ n }}</span>
    <hr>
    <ul>
      <template v-for="item in items">
        <li>{{ item.desc }}</li>
      </template>
    </ul>
    <h2>필터</h2>
    <ul>
        <li v-for="n in evenNumbers" :key="n">{{ n }}</li>
    </ul>
    <hr>
    <ul v-for="numbers2 in sets">
      <li v-for="n in even(numbers2)">{{ n }}</li>
    </ul>
  </div>
</template>

 