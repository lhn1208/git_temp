import { createRouter, createWebHashHistory } from 'vue-router';
import Home from '../components/Home';
import Portfolio from '../components/Portfolio';
import About from '../components/About';


const router = createRouter({
  history: createWebHashHistory(),
  base: '/vue-deploy/',// "base" 옵션을 설정합니다.
  routes:[
    {
      path: '/',
      name: 'Home',
      component: Home
      
    },
    {
      path: '/portfolio',
      name: 'Portfolio',
      component: Portfolio,
      // beforeRouteLeave(to, from, next) {
      //   next();
      // },
    },
    {
      path: '/about',
      name: 'About',
      component: About,
      // beforeRouteLeave(to, from, next) {
      //   next();
      // },
    }
  ]
});

export default router;