<template>
    <footer class="footer">COPYRIGHT(c) HANA'S PORTFOLIO ALL RIGHTS RESERVED
		<i>*해당페이지는 반응형으로 제작되었습니다.</i>
	</footer>
</template>
<script>
/* eslint-disable */
export default {
  name: 'Footer',
  mounted() {
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://www.googletagmanager.com/gtag/js?id=G-FC919YF7SP';
    document.head.appendChild(script);

    window.dataLayer = window.dataLayer || [];
    function gtag() { dataLayer.push(arguments); }
    gtag('js', new Date());

    gtag('config', 'G-FC919YF7SP');
  }
}
</script>
<style scoped>
/*footer*/
.footer{height: 116px; padding:var(--content-pd) 0; font-size: 18px; background: var(--primary-color); color: var(--white-color); text-align: center; box-sizing: border-box;}
.footer i{display: block; font-size: 12px;}
@media (max-width: 767px){ 
  .footer{font-size: var(--mb-font-size);}
}
@media (max-width: 480px){
 .footer{font-size: 12px;}
}
</style>