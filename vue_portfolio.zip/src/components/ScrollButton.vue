<template>
    <button class="scroll_btn" @click="gotoTop()">
        <i></i>
    </button>
</template>
<script>
/* eslint-disable */
export default {
  name: 'ScrollButton',
  methods: {
    gotoTop(){
        const bottom_bt=document.querySelector('.scroll_btn');
         window.scrollTo({top:0})
    }
  }
}
</script>
<style scoped>
.scroll_btn{display:flex; align-items: center; justify-content: center; position:fixed; bottom:15px; right:20px; z-index: 999;width: 60px; height: 60px; background-color: var(--primary-color); border-radius: 50%;}
.scroll_btn i{display: inline-block; width: 10px; height: 10px; border-bottom: 2px solid #fff; border-right: 2px solid var(--white-color); transform: rotate(-135deg); margin-top: 10%;}
@media (max-width: 767px){
  .scroll_btn{width: 45px; height: 45px;}
}
</style>