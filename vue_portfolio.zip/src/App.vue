<template>
  <div id="app">
    <Header v-if="showHeader" :class="{'white_type': whiteType}" />
    <router-view></router-view>
    <ScrollButton v-if="showscrollBtn" />
    <Footer v-if="showFooter" />
  </div>
</template>

<script>
import Header from '@/components/Header.vue';
import Footer from '@/components/Footer.vue';
import ScrollButton from '@/components/ScrollButton.vue';
export default {
  name: 'App',
  data() {
    return {
      showHeader: true,
      showFooter: true,
      whiteType: false,
    };
  },
  components: {
    Header,
    Footer,
    ScrollButton
  },
  mounted() {
    this.updatePageVisibility(this.$route.path);
  },
  watch: {
    '$route.path': function(newPath) {
      this.updatePageVisibility(newPath);
       this.logWhiteType();
    },
  },
  methods: {
     logWhiteType() {
      // console.log(this.$route.path);
      // console.log(this.whiteType);
    },
    updatePageVisibility(path) {
      this.showHeader = path !== '/';
      this.showFooter = path !== '/';
      this.showscrollBtn = path !== '/';
      this.whiteType = path === '/About';
    },
  },
};

</script>