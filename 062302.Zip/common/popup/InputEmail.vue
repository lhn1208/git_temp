 <script setup>
 </script>
 <template>
   <li class="email_form">  
      <input class="input" type="text" title="이메일 입력 하세요." placeholder="이메일 입력">  
      <select>
          <option>이메일선택</option>
          <option>naver.com</option>
          <option>gmail.com</option>
          <option>daum.com</option>
      </select>
    </li>
 </template>