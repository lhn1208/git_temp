<script setup>

</script>
<template>
    <ul class="offer_img_list">
        <li class="main_img"><a href="#"><img src="@/assets/images/sub/offering_main_img.jpg"></a></li>
        <li><a href="#"><img src="@/assets/images/sub/offering_img1.jpg"></a></li>
        <li><a href="#"><div class="cover"><span>15개 사진 전체보기</span></div><img src="@/assets/images/sub/offering_img2.jpg"></a></li>
    </ul>
</template>