<script setup>
import { defineProps } from 'vue';
const props = defineProps({
  title: {
    type: String,
    required: true
  },
  titleClass:{
    type: String, 
    required: false, 
    default: ''
  },
  text1: {
    type: String,
    required: true
  },
  text2: {
    type: String,
    required: false
  },
  btnText: {
    type: String,
    required: false
  },
});
</script>
<template>
   <div class="top_tit_area">
        <h2 :class="titleClass">{{title}}</h2>
        <p class="text">{{text1}}<span v-if="text2">/{{ text2 }}</span></p>
        <button class="btn_round ab_right">{{ btnText }}</button>
   </div>
</template>