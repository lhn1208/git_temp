<script setup>
import { ref, onMounted, onUnmounted } from 'vue';
import { RouterLink, RouterView } from 'vue-router'
const isFixed = ref(false);

const handleScroll = () => {
  if (window.scrollY > 0) {
    isFixed.value = true;
  } else {
    isFixed.value = false;
  }
};
onMounted(() => {
  window.addEventListener('scroll', handleScroll);
});
onUnmounted(() => {
  window.removeEventListener('scroll', handleScroll);
});
</script>
<template>
    <header :class="['header', { fixed: isFixed }]">
        <nav class="nav">
            <ul>
                <li><RouterLink to="/">메인</RouterLink></li>
                <li><RouterLink to="/myhome">마이홈</RouterLink></li>
                <li><RouterLink to="/offerings_sch">매물검색</RouterLink></li>
                <li><RouterLink to="/visitReq">방문요청</RouterLink></li>
                <li><a href="#">나의 매도</a></li>
            </ul>
        </nav>
        <a href="#" class="manage">공인중개사</a>
        <ul class="member">
            <li><a href="#">로그인</a></li>
            <li><a href="#">회원가입</a></li>
        </ul>
    </header>
</template>