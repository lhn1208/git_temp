<script setup>
import { RouterLink, RouterView } from 'vue-router'
import Main from './main/Main.vue'
</script>

<template>
  <div>
    <!-- <img alt="Vue logo" class="logo" src="@/assets/logo.svg" width="125" height="125" /> -->

    <Main />
  </div>

</template>

<style scoped>

</style>
