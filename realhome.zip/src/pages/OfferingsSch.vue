<script setup>
import OfferItemHeader from '../components/OfferItemHeader.vue';
import ItemBox from '../components/ItemBox.vue'
</script>
<template>
    <div class="sub_content type">  
        <div class="offer_set_box">
            <h2 class="set_tit">설정</h2>
            <div class="set_sch_form">
    
            </div>
        </div>
        <div class="offerings_wrap">
            <div class="content">
               
            </div>
            <aside class="offer_items type">
                <OfferItemHeader 
                    title="전체매물"
                    totalCnt="21"
                />
                <div class="items_wrap">
                    <div class="item">
                        <ItemBox 
                            alt="매물 이미지1" 
                            src="src/assets/images/main/offering_img1.jpg" 
                            price="매매 3억 5000" 
                            info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
                            type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
                            addr="잠실주공1단지 104동잠실"
                            onClass="on"
                        />
                    </div>
                    <div class="item">
                        <ItemBox 
                            alt="매물 이미지1" 
                            src="src/assets/images/main/offering_img1.jpg" 
                            price="매매 3억 5000" 
                            info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
                            type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
                            addr="잠실주공1단지 104동잠실"
                        />
                    </div>
                </div>
            </aside>
        </div>

    </div>
</template>