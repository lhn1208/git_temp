<script setup>
import { ref } from 'vue';
import OfferItemHeader from '../components/OfferItemHeader.vue';
import ItemBox from '../components/ItemBox.vue'
import OfferImg from '../components/OfferImg.vue'
import OfferInfo from '../components/OfferInfo.vue'

const offerDate = ref([
    { floor: '6/15층', date: '2002.09(15년)', loan: '시세 30% 미만', elevator: 'Y', park: 'Y', pet:'N'}
  ]);

</script>
<template>
    <div class="sub_content type">  
        <div class="offerings_wrap">
            <div class="content">
                <h2 class="title">방문 요청</h2>
                <OfferImg />
                <div class="offer_info_list">
                    <OfferInfo 
                        title="월세보증금/월세"
                        content="1억1000/50"
                        type="amt"
                    />
                    <OfferInfo 
                        title="전용면적"
                        content="33.9㎡(10)"
                    />
                    <OfferInfo 
                        title="방수/욕실수"
                        content="원룸(개방형)/1개"
                    />
                </div>
                <section class="section">
                    <table class="offer_tb">
                        <caption>매물정보 메인 테이블</caption>
                        <colgroup>
                            <col width="16%">
                            <col width="34%">
                            <col width="16%">
                            <col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th>해당층/건물층</th>
                                <td>6/15층</td>
                                <th>준공월</th>
                                <td>2002.09(15년)</td>
                            </tr>
                        </tbody>
                    </table>
                </section>
            </div>
            <aside class="offer_items">
                <div class="top_area">
                    <button class="btn_square">요청 전송</button>
                    <p class="desc">※ 방문하고 싶은 매물을 모두 선택 후, [요청 전송]을 누르십시오.</p>
                </div>
                <OfferItemHeader 
                    title="전체매물"
                    currentCnt="4"
                    totalCnt="5"
                    text="(방문요청 가능매물/전체 추천매물)"
                />
                <div class="items_wrap">
                    <div class="item">
                        <ItemBox 
                            alt="매물 이미지1" 
                            src="src/assets/images/main/offering_img1.jpg" 
                            price="매매 3억 5000" 
                            info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
                            type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
                            addr="잠실주공1단지 104동잠실"
                            onClass="on"
                        />
                        <div class="bottom_box">
                            <div class="check_form">
                                <input type="checkbox" name="" id="check1" class="checkbox">
                                <label for="check1">방문요청</label>
                            </div>
                            <span class="date">23.06.06</span>
                        </div>
                    </div>
                    <div class="item">
                        <ItemBox 
                            alt="매물 이미지1" 
                            src="src/assets/images/main/offering_img1.jpg" 
                            price="매매 3억 5000" 
                            info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
                            type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
                            addr="잠실주공1단지 104동잠실"
                        />
                        <div class="bottom_box">
                            <div class="check_form">
                                <input type="checkbox" name="" id="check2" class="checkbox">
                                <label for="check2">방문요청</label>
                            </div>
                            <span class="date">23.06.06</span>
                        </div>
                    </div>
                    <div class="item">
                        <ItemBox 
                            alt="매물 이미지1" 
                            src="src/assets/images/main/offering_img1.jpg" 
                            price="매매 3억 5000" 
                            info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
                            type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
                            addr="잠실주공1단지 104동잠실"
                        />
                        <div class="bottom_box">
                            <div class="check_form">
                                <input type="checkbox" name="" id="check3" class="checkbox">
                                <label for="check3">방문요청</label>
                            </div>
                            <span class="date">23.06.06</span>
                        </div>
                    </div>
                    <div class="item">
                        <ItemBox 
                            alt="매물 이미지1" 
                            src="src/assets/images/main/offering_img1.jpg" 
                            price="매매 3억 5000" 
                            info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
                            type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
                            addr="잠실주공1단지 104동잠실"
                        />
                        <div class="bottom_box">
                            <div class="check_form">
                                <input type="checkbox" name="" id="check4" class="checkbox">
                                <label for="check4">방문요청</label>
                            </div>
                            <span class="date">23.06.06</span>
                        </div>
                    </div>
                </div>
            </aside>
        </div>

    </div>
</template>