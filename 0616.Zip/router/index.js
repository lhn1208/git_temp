import { createRouter, createWebHistory } from 'vue-router'
import Main from '../user/Main.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'main',
      component: Main
    },
    {
      path: '/myhome',
      name: 'myhome',
      component: () => import('../user/Myhome.vue')
    },
    { //매물검색
      path: '/offeringsSch',
      name: 'offerings_sch',
      component: () => import('../offerings/OfferingsSch.vue')
    },
    {
      path: '/VisitReq',
      name: 'visitRequest',
      component: () => import('../offerings/VisitReq.vue')
    },
    {
      //나의 매수
      path: '/myPurchase',
      name: 'myPurchase',
      component: () => import('../trading/MyPurchase.vue')
    },
    { //나의 매도
      path: '/mySale',
      name: 'mySale',
      component: () => import('../trading/MySale.vue')
    },
    {//나의 매수-신규 중개의뢰
      path: '/newReq1',
      name: 'newReq1',
      component: () => import('../trading/NewReq1.vue')
    },
    {
      path: '/newReq2',
      name: 'newReq2',
      component: () => import('../trading/NewReq2.vue')
    },
    {
      path: '/newReq3',
      name: 'newReq3',
      component: () => import('../trading/NewReq3.vue')
    },
    {
      path: '/newReq4',
      name: 'newReq4',
      component: () => import('../trading/NewReq4.vue')
    },
    {
      path: '/newReqEnd',
      name: 'newReqEnd',
      component: () => import('../trading/NewReqEnd.vue')
    },
    { //나의 매도-신규 중개의뢰
      path: '/SalenewReq1',
      name: 'SalenewReq1',
      component: () => import('../trading/SaleNewReq1.vue')
    },
    {
      path: '/SalenewReq2',
      name: 'SalenewReq2',
      component: () => import('../trading/SaleNewReq2.vue')
    },
    {
      path: '/SalenewReq3',
      name: 'SalenewReq3',
      component: () => import('../trading/SaleNewReq3.vue')
    },
    {
      path: '/SaleNewReqEnd',
      name: 'SaleNewReqEnd',
      component: () => import('../trading/SaleNewReqEnd.vue')
    },
    {
      //나의 매수-매수/임차 진행현황
      path: '/PurchaseState',
      name: 'PurchaseState',
      component: () => import('../trading/PurchaseState.vue')
    },
    {//추가 방문요청
      path: '/AddVisitReq',
      name: 'AddVisitReq',
      component: () => import('../offerings/AddVisitReq.vue')
    },
    {//나의 매수-매수/임차 계약,종료 현황
      path: '/PurchaseStateEnd',
      name: 'PurchaseStateEnd',
      component: () => import('../trading/PurchaseStateEnd.vue')
    },
    {
      //나의 매도-매도/임대 진행현황
      path: '/SaleState',
      name: 'SaleState',
      component: () => import('../trading/SaleState.vue')
    },
    {
      //나의 매도-매도/임대 계약,종료현황
      path: '/SaleStateEnd',
      name: 'SaleStateEnd',
      component: () => import('../trading/SaleStateEnd.vue')
    },
    {
      path: '/Customer',
      name: 'Customer',
      component: () => import('../customer/Customer.vue')
    },
  ],
  scrollBehavior (to, from, savedPosition) {
    // savedPosition은 브라우저의 "뒤로 가기" 버튼을 클릭할 때 저장된 위치를 반환합니다.
    if (savedPosition) {
      return savedPosition
    } else {
      return { x: 0, y: 0 }
    }
  }
})

export default router
