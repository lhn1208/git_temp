<script setup>
import { ref } from 'vue';
import './customer.css'
import TopArea from '../components/TopArea.vue';
import Tab from '../common/Tab.vue';

const activeTab = ref('tab1');
const updateTab = (tab) => {
  activeTab.value = tab;
};
</script>
<template>
   <div class="sub_content" id="content">
      <TopArea  
        title="고객센터" 
        titleClass="f_blue" 
        text1="리얼하우스는 좋은 서비스를 위해 최선을 다하겠습니다." 
        btnText="닫기" 
        link="main"
      />
      <Tab
      tabTit1="공지사항"
      tabTit2="뉴스"
      tabTit3="1대1 문의"
      @updateTab="updateTab"
      />
      <!--tab1-->
      <div v-if="activeTab === 'tab1'">
         <ul class="box_list">
            <li>
              <a href="#">공지사항 입니다.<span class="rd_ico red sm">NEW</span></a>
              <span class="date">2023.04.10</span>
            </li>
         </ul>
      </div>
      <!--//tab1-->
      <!--tab2-->
      <div v-if="activeTab === 'tab2'">
           <ul class="box_list">
            <li></li>
         </ul>
      </div>
      <!--//tab2-->

   </div>
</template>