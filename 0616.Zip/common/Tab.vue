<script setup>
import { defineProps, defineEmits, ref  } from 'vue';
const props = defineProps({
  tabTit1:String,
  tabTit2:String,
  tabTit3:String,
  num1: String,
  num2: String,
  offerType: Boolean,
  addClass: {
    type: String, 
    default: ''
  },
  myPurchase:Boolean
});
const emit = defineEmits(['updateTab']);
const activeTab = ref('tab1'); //on클래스

const handleClick = (tab) => {
  activeTab.value = tab;
  emit('updateTab', tab);
};
</script>
<template>
   <div :class="[addClass, 'tab_container']">
    <div class="tab_btn">
        <button :class="{ on: activeTab === 'tab1' }" @click="handleClick('tab1')">{{tabTit1}}<span v-if="num1">({{num1}})</span></button>
        <button :class="{ on: activeTab === 'tab2' }" @click="handleClick('tab2')">{{tabTit2}}<span v-if="num2">({{num2}})</span></button>
        <button :class="{ on: activeTab === 'tab3' }" @click="handleClick('tab3')" v-if="tabTit3">{{tabTit3}}</button>
    </div>
    <div class="select_area row" v-if="myPurchase || offerType">
      <select v-if="myPurchase">
        <option value="">계약/종료 선택</option>
        <option value="">전체</option>
        <option value="">계약완료</option>
        <option value="">계약종료</option>
      </select>
      <select>
        <option value="">거래구분 선택</option>
        <option value="">전체</option>
        <option value="">매매</option>
        <option value="">전세</option>
        <option value="">월세</option>
        <option value="">단기임대</option>
      </select>
      <select v-if="offerType">
        <option value="">매물유형 선택</option>
        <option value="">전체</option>
        <option value="">매매</option>
        <option value="">전세</option>
        <option value="">월세</option>
        <option value="">단기임대</option>
      </select>
    </div>
</div>
</template>