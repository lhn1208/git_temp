<script setup>
import { defineProps} from 'vue';
import { useRouter } from 'vue-router';
const props = defineProps({
  title: String,
  icoShow:Boolean,
  icoTxt:String,
  offerInfo: String,
  lists: {
    type: Object,
    required: false,
    default: () => ({})
  },
  numClass:String,
  link:String
});
const router = useRouter();
const navigate = () => {
  if (props.link) {
    router.push(`/${props.link}`);
  }
};
</script>
<template>
   <div class="box_wrap">
    <a href="#" class="box trading_box"  @click.prevent="navigate">
        <h3 class="title">{{title}}</h3><i class="rd_ico red" v-if="icoShow">{{icoTxt}}</i>
        <p>{{offerInfo}}</p>
        <ul class="info_list"><li v-for="(list, index) in lists" :key="index">{{list.listTit}}<span :class="numClass">{{list.listVal}}</span></li></ul>
    </a>
  </div>
</template>