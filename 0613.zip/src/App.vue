<script setup>
import { RouterLink, RouterView } from 'vue-router'
import Header from './common/Header.vue'
</script>

<template>
  
  <Header />
  <RouterView />

</template>

<style scoped>

</style>
