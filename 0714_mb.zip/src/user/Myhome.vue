<script setup>
import './user.css'
import IntroBox from './IntroBox.vue';
import { useRouter } from 'vue-router';
const router = useRouter();
  const navigate = (link) => {
   if(link==='notice'){
    router.push(`/notice`);
   }else if(link==='qna'){
    router.push(`/qna`);
   }
};
</script>
<template>
  <div class="content_w sub_content">
    <div class="myhome">
      <div class="top_info">
        <em class="name">홍길동</em>
        <span class="email">your@gmail.come</span>
        <button class="btn_set">설정</button>
      </div>
      <IntroBox title="중개의뢰 관리요청"
        :num="3"
        text="지인이나 중개사가 중개의뢰를 관리요청한 내역이 나타납니다."
        linkText="관리요청 확인"
      />
      <div class="box_wrap point_box">
        <div class="box intro_box flex_both_ends">
            <strong class="f_red">포인트</strong>
            <div><em class="f_blue">100,000</em>원</div>
        </div>
        <div class="box_bottom">
            <ul>
              <li><a href="#">사용방법</a></li>
              <li><a href="#">포인트 내역</a></li>
              <li><a href="#">중개수수료 결제</a></li>
            </ul>
        </div>
      </div>
      <IntroBox title="1:1문의"
        :num="1"
        text="궁금하신 사항이나 개선사항 등을 문의하십시오."
        linkText="문의 관리"
        link="qna"
      />
      <div class="notice_box">
          <header class="flex_both_ends">
             공지사항
             <button class="f_blue" @click.prevent="navigate('notice')">더보기<span class="link_arr">아이콘</span></button>
          </header>
          <ul>
            <li class="">
              <div class="row flex_both_ends">
                  <div class="title">
                    <a href="#" @click.prevent="navigate('notice')">해당 공지사항이 나타납니다.해당 공지사항이 나타납니다.해당 공지사항이 나타납니다.</a><span class="rd_ico">new</span>
                  </div>
                  <span class="date">2023.04.05</span>
              </div>
            </li>
            <li class="">
              <div class="row flex_both_ends">
                  <div class="title">
                    <a href="#" @click.prevent="navigate('notice')">해당 공지사항이 나타납니다.</a><span class="rd_ico">new</span>
                  </div>
                  <span class="date">2023.04.05</span>
              </div>
            </li>
          </ul>

      </div>
    </div>
 
  </div>
</template>