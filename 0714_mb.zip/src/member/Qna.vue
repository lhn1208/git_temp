<script setup>
import './member.css'
import Header from '../common/Header.vue'
import QnaItem from './QnaItem.vue'
import { useRouter } from 'vue-router';
const router = useRouter();
 const navigate = () => {
   router.push(`/qnaWrite`);
};

</script>
<template>
<div class="qna sub_content">
  <Header title="1:1 문의" link="myhome" />
  <QnaItem 
    title="문의제목이 나타납니다"
    rdText="미답변"
    date="23.10.10"
    text="문의 내용입니다.
        <br>문의 내용입니다.
        <br>문의 내용입니다.
        <br>문의 내용입니다."
  />
  <QnaItem 
    title="문의제목이 나타납니다2"
    addClass="grass"
    rdText="답변완료"
    date="23.09.30"
    text="문의 내용입니다.2
        <br>문의 내용입니다.2
        <br>문의 내용입니다.2
        <br>문의 내용입니다.2"
  />
  <div class="bottom_btn">
    <button @click.prevent="navigate">문의하기</button>
  </div>
</div>
</template>