 <script setup>
  import { defineProps } from 'vue';
  const props = defineProps({
    title: String,
    rdText:String,
    addClass:String,
    date:String,
    text:String,
  });
import {ref} from 'vue';
const contToggleClass = ref(false);
const ToggleEv = () => {
     contToggleClass.value = !contToggleClass.value;
};
</script>
<template>
 <div>
    <button class="item_row notice_row" @click="ToggleEv">
        <div class="flex"><strong class="title">{{title}}</strong><span :class="[addClass, 'rd_ico']">{{rdText}}</span></div>
        <span class="date">{{date}}</span>
        <span class="link_arr down"></span>
    </button>
    <div :class="{'cont': true, 'active': contToggleClass}">
      <div class="cont_in" v-html="text">
      </div>
    </div>
   </div>
</template>