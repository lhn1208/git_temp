<script setup>
import './member.css'
import Header from '../common/Header.vue'
const NoticeEv = (event) => {
  event.preventDefault();
  // Your logic here
};
</script>
<template>
<div>
   <Header title="공지사항" link="myhome" />
   <a href="#" class="item_row notice_row"  @click.prevent="NoticeEv">
      <div class="flex"><strong class="title">공지사항 제목이 나타납니다.</strong><span class="rd_ico">new</span></div>
      <span class="date">23.10.10</span>
      <span class="link_arr"></span>
   </a>
    <a href="#" class="item_row notice_row"  @click.prevent="NoticeEv">
      <div class="flex"><strong class="title">공지사항 제목이 나타납니다.</strong></div>
      <span class="date">23.09.30</span>
      <span class="link_arr"></span>
   </a>
</div>
</template>