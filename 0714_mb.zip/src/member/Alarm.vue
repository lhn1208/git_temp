<script setup>
  import './member.css'
  import Header from '../common/Header.vue'
  import AlarmItem from './AlarmItem.vue'
</script>
<template>
  <div>
    <Header title="알림" link="/" />
    <div class="alarm sub_content">
        <AlarmItem 
          title="매물사진 삭제"
          date="12:05"
          :icoNew="true"
          text="워터마크 등으로 인해 사진의 일부 또는 전부가 삭제되었으며 평점이 감점되었습니다."
        />
         <AlarmItem 
          title="의뢰인 방문"
          date="23.05.15"
          text="의뢰인 방문시간(18.09.03 11:50) 30분전 알림입니다."
        />
        <AlarmItem 
          title="중개사무소 방문"
          date="23.05.10"
          text="은성공인중개사무소(홍길동) 방문시간(23.05.10 11:50) 30분전 알림입니다."
        />
        <AlarmItem 
          title="메모 일정"
          date="23.05.08"
          text="매수/임차 중개의뢰의 메모일정(23.05.08 11:50) 30분전 알림입니다."
        />
    </div>
   
  </div>
</template>