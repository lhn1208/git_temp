<script setup>
import './member.css'
import Header from '../common/Header.vue'
import { useRouter } from 'vue-router';
const router = useRouter();
const navigate = (link) => {
   if(link==='qna'){
    router.push(`/qna`);
   }
};

</script>
<template>
<div class="qna sub_content">
  <Header title="1:1 문의" link="myhome" />
  <div class="qna_form">
    <input type="text" class="input" title="제목을 입력하세요" placeholder="제목을 입력하세요">
    <textarea class="textarea" title="내용을 입력하세요" placeholder="내용을 입력하세요"></textarea>
  </div>
  <div class="bottom_btn col2">
    <button @click.prevent="navigate('qna')">취소</button>
    <button>등록</button>
  </div>
</div>
</template>