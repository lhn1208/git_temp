<script setup>
import './agent.css';
</script>
<template>
    <div class="box_wrap">
       <div class="box agent_intro_box">
            <figure>
                <img alt="중개사사진" src="@/assets/images/sub/sample/img_agent.png" />
            </figure>
            <figcaption>
                <ul class="info">
                    <li><em>중개사</em>홍길동(대표공인중개사)</li>
                    <li><em>중개사무소</em>중개법인잠실은성공인사사무소</li>
                    <li><em>주소</em> 서울시 송파구 잠실동 321-1(대성빌딩) 301호</li>
                </ul>
            </figcaption>
       </div>
    </div>
</template>