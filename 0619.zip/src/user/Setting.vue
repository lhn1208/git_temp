<script setup>
import TopArea from '../components/TopArea.vue'
</script>
<template>
    <div class="sub_content" id="content">
        <div class="setting">
            <TopArea title="개인정보 설정" titleClass="f_blue" text1="개인정보를 변경하실 수 있습니다."/> 
            <div class="table_style">
                <table class="table">
                    <caption>이름,이메일,휴대전화,비밀번호로 구성된 테이블</caption>
                    <colgroup>
                        <col width="14%">
                        <col>
                    </colgroup>
                    <tbody>
                        <tr>
                            <th>이름</th>
                            <td><div class="flex_both_ends">
                                    <span>홍길동</span>
                                    <button class="btn_square basic btn">변경</button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>이메일</th>
                            <td><div class="flex_both_ends">
                                    <span>test@naver.com</span>
                                    <button class="btn_square basic btn">변경</button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>휴대전화</th>
                            <td><div class="flex_both_ends">
                                    <span>000-0000-0000</span>
                                    <button class="btn_square basic btn">변경</button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>비밀번호</th>
                            <td><div class="flex_both_ends">
                                    <input type="password" value="12345" class="member_pw" disabled>
                                    <button class="btn_square basic btn">변경</button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <button class="btn_leave">회원탈퇴</button>
        </div>      
    </div>
</template>