<script setup>
</script>
<template>
    <div class="paging">
        <a href="#" class="arr_ico prev"><span class="hidden">이전</span></a>
        <div class="paging_num">
        <a href="#" class="on">1</a>
        <a href="#">2</a>
        <a href="#">2</a>
        <a href="#">4</a>
        </div>
        <a href="#" class="arr_ico next"><span class="hidden">다음</span></a>
    </div>
</template>