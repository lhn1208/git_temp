export default [
  { text: '뉴스가 나타납니다1', isNew: 'NEW', date: '22.12.10' },
  { text: '뉴스가 나타납니다2', date: '22.12.11' },
  { text: '뉴스가 나타납니다3', date: '22.12.12' }
]