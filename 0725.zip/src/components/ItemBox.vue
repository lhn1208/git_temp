<script setup>
  import { defineProps } from 'vue';
  const props = defineProps({
     alt:String,
     title:String,
     info:String,
     type:String,
     labels:{
      type: Object,
      required: false,
      default: () => ({})
    },
    addr:String,
    seen:Boolean,
    dealEnd:Boolean,
  });
  const prevEv = (event) => {
    event.preventDefault(); 
  };
</script>
<template>
  <a class="item" href="#"  @click.prevent="prevEv">
    <div class="item_in">
        <figure>
          <div v-if="dealEnd" class="cover"><span class="txt">거래완료</span></div>
          <div v-if="seen" class="seen"><span class="txt">SEEN</span></div>
          <img :alt="alt" src="@/assets/images/sub/img_offering2.jpg" />
        </figure>
        <figcaption>
          <strong>{{title}}</strong>
          <div class="item_info">
            <span>{{info}}</span>
            <div class="label_row">
              <i class="point">{{ type }}</i>
              <i v-for="(label, index) in labels" :key="index">{{ label }}</i> 
            </div>
            <span>{{addr}}</span>
          </div>
        </figcaption>
    </div>
  </a>
</template>