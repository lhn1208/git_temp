  <script setup>
  import { ref } from 'vue';
  import { useRouter } from 'vue-router';
  import { Swiper, SwiperSlide } from 'swiper/vue';
  import 'swiper/css';
  import './user.css'
  import IntroBox from './IntroBox.vue';
  import ItemBox from './Itembox.vue';
  const router = useRouter();
  const navigate = (link) => {
   if(link==='offer'){
    router.push(`/rcnOffer`);
   }
  };
  </script>
  <template>
    <main class="main content_w">
      <h1 class="main_tit">헛걸음은 없다
        <p>허위매물이 근본적으로<br>차단되는 하우스!</p>
      </h1>
      <button class="btn_sch"></button>
      <IntroBox title="오픈 추천 이벤트"
        bg_Class="bg_gift"
        titleClass="f_emerald"
        text="10억 지급 오픈 이벤트가 1달간(5/31까지) 진행되며<br>포인트는 중개수수료를 납부하실 수 있습니다."
        linkText="이벤트 확인/참여"
        link="openEvent"
      />
       <IntroBox title="관심 매물"
        :num="2"
        text="관심매물로 등록한 매물을 관리할 수 있습니다."
        linkText="관심매물 관리"
         link="favOffer"
      />
      <section>
        <div class="flex_both_ends">
          <h2 class="h2_title">최근 본 매물</h2>
          <a href="#" class="f_blue link" @click.prevent="navigate('offer')">더 보기<span class="link_arr">바로가기</span></a>
        </div>
        <div class="offer_items">
          <div class="swiper_wrap">
              <swiper class="swiper"
                :slidesPerView="2"
                :spaceBetween="20"
              >
                <swiper-slide><ItemBox 
                  alt="매물 이미지1" 
                  type="전세/월세 | 잠실동" 
                  price="2억5000 | 3룸 | 82㎡(25)" 
                  />
                </swiper-slide>
                <swiper-slide><ItemBox 
                  alt="매물 이미지2" 
                  type="전세/월세 | 잠실동" 
                  price="2억5000 | 3룸 | 82㎡(25)" 
                  />
                </swiper-slide>
                <swiper-slide><ItemBox 
                  alt="매물 이미지2" 
                  type="전세/월세 | 잠실동" 
                  price="2억5000 | 3룸 | 82㎡(25)" 
                  />
                </swiper-slide>
              </swiper>
          </div>
        </div>
      </section>
      <div class="box_wrap">
          <div class="box intro_box bg_intro">
              <strong class="f_emerald tit">리얼하우스는 왜 다른가?</strong>
              <p>허위/미끼 매물 없는<span class="f_red">리얼하우스</span>!!
                 <br>이젠,매물을 보고 <span class="f_red">일일이 전화하지 않으셔도 됩니다.</span>
              </p>
          </div>
      </div>
    </main>
  </template>

