  <script setup>
  import { defineProps } from 'vue';
  import { useRouter } from 'vue-router';
  const props = defineProps({
     alt:String,
     type:String,
     price:String
  });
  const router = useRouter();
  const navigate = () => {
    router.push(`/rcnOffer`);
  };
  </script>
  <template>
  <a href="#" class="item" @click.prevent="navigate">
    <figure>
      <img :alt="alt" src="@/assets/images/sub/img_offering.jpg" />
    </figure>
    <figcaption>
      <strong>{{type}}</strong>
      <span>{{price}}</span>
    </figcaption>
  </a>
  </template>
