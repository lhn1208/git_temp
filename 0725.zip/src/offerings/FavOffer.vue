<script setup>
import './offerings.css'
import ItemBox from '../components/ItemBox.vue'
import Header from '../common/Header.vue'
import BottomBtn from '../common/BottomBtn.vue'
</script>
<template>
<div>
  <Header title="관심 매물" link="/" />
  <div class="items_wrap">
    <ItemBox 
        alt="매물 이미지1" 
        title="월세 5억1000/50" 
        info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
        type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
        addr="잠실주공1단지 104동잠실"
        :seen="true"
    />
    <ItemBox 
        alt="매물 이미지1" 
        title="월세 5억1000/50" 
        info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
        type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
        addr="잠실주공1단지 104동잠실"
        :dealEnd="true"
    />
    <ItemBox 
        alt="매물 이미지1" 
        title="월세 5억1000/50" 
        info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
        type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
        addr="잠실주공1단지 104동잠실"
    />
     <ItemBox 
        alt="매물 이미지1" 
        title="월세 5억1000/50" 
        info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
        type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
        addr="잠실주공1단지 104동잠실"
    />
  </div>
  <BottomBtn addClass="col2" btnTxt1="전체 관심 매물 삭제" btnTxt2="거래 완료 매물 삭제"/>
</div>
</template>