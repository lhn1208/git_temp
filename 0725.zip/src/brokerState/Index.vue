<script setup>
import './brokerage.css'
import { Swiper, SwiperSlide } from 'swiper/vue';
import { ref } from 'vue';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import TopIntro from './TopIntro.vue'
import StateBox from './StateBox.vue'

const slides = ['나의 매수(3)', '나의 매도(2)'];
const swiperTabs = ref(null);
const swiperContent = ref(null);
const activeIndex = ref(0);  // 현재 활성화된 슬라이드 인덱스

// Swiper 인스턴스를 초기화하고 ref 변수에 할당
const onSwiperTabsInit = (swiper) => {
  swiperTabs.value = swiper;
};
const onSwiperContentInit = (swiper) => {
  swiperContent.value = swiper;
};
// 탭 Swiper가 슬라이드될 때 호출되는 함수
const onTabSlideChange = (swiper) => {
   activeIndex.value = swiper.activeIndex;  // 활성화된 인덱스 업데이트
  swiperContent.value.slideTo(swiper.activeIndex);
};

const onContentSlideChange = (swiper) => {
  activeIndex.value = swiper.activeIndex;  // 활성화된 인덱스 업데이트
  swiperTabs.value.slideTo(swiper.activeIndex);
};

const goToSlide = (index) => {
  activeIndex.value = index;  // 활성화된 인덱스 업데이트
  swiperTabs.value.slideTo(index);
  swiperContent.value.slideTo(index);
};

</script>
<template>
  <div class="broderage">
   <header>
      <div class="swiper_wrap">
        <!-- 탭 swiper-->
        <Swiper
          class="swiper_header"
          :slidesPerView="2"
          @slideChange="onTabSlideChange"
          @swiper="onSwiperTabsInit"
        >
          <SwiperSlide v-for="(slide, index) in slides" 
            :key="index" 
            :class="{ active: activeIndex === index }"  
            @click="goToSlide(index)"
          >
            {{ slide }}
          </SwiperSlide>
        </Swiper>
      </div>
    </header>
    <div class="brokage_cont">
      <Swiper
        class="swiper"
        :slidesPerView="1"
        @slideChange="onContentSlideChange"
        @swiper="onSwiperContentInit"
      >
        <SwiperSlide>
          <div class="content_w">
            <TopIntro title="나의매수"
                addClass="f_red"
                text="매수/임차 중개의뢰를 통해 보다 좋은 매물을 빠르게 계약하실 수 있습니다."
                :btn="true"
            />
          </div>
          <StateBox title="주거용 | 월세"
            date="23.06.10"
            :none="true"
            :state="true"
            :num1="0"
            :num2="0"
            :num3="0"
            :num4="0"
            :mysale="true"
            visit="23.06.12(월) 14시 30분"
          />
          <StateBox title="주거용 | 월세"
            date="23.06.10"
            info="홍길동(은성공인중개사무소)"
             :state="true"
            :num1="5"
            :num2="12"
            :num3="10"
            :num4="7"
            :mysale="true"
            visit="23.06.12(월) 14시 30분"
          />
           <StateBox title="주거용 | 월세"
            date="23.06.10"
            info="홍길동(은성공인중개사무소)"
             :state="true"
            :num1="10"
            :num2="10"
            :num3="10"
            :num4="2"
            :mysale="true"
            visit="23.06.06(월) 14시 30분"
            :btn="true"
          />
          
                   
        </SwiperSlide>
        <SwiperSlide>
          <div class="content_w">
            <TopIntro title="나의매도"
              addClass="f_blue"
              text="매도/임대 중개의뢰는 PC에서 요청하실 수 있으며 요청 후 중개현황은 앱에서도 확인가능합니다."
            />
          </div>
         <StateBox title="주거용 | 월세"
            date="23.06.10"
            :none="true"
            addr="잠실주공아파트"
            addrDetail="102동 102호"
          />
           <StateBox title="주거용 | 월세"
            date="23.06.10"
            info="홍길동(은성공인중개사무소)"
            addr="장미아파트"
            addrDetail="110동 504호"
          />
        </SwiperSlide>
        
      </Swiper>
    </div>
  </div>
</template>