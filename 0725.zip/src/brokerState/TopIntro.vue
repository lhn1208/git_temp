<script setup>
   import { defineProps } from 'vue';
  const props = defineProps({
      title:String,
      addClass:String,
      text:String,
      btn:Boolean
  });
</script>
<template>
  <div class="top_intro">
    <strong :class="[addClass, 'title']">{{title}}</strong>
    <div class="intro_txt">
        <span>{{text}}</span>
        <button v-if="btn" class="btn_round bg">신규 중개의뢰</button>
    </div>
  </div>
</template>