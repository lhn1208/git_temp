<script setup>
   import { defineProps } from 'vue';
  const props = defineProps({
      title:String,
      addClass:String,
      date:String,
      info:String,
      num1:Number,
      num2:Number,
      num3:Number,
      num4:Number,
      visit:String,
      btn:Boolean,
      none:Boolean,
      state:Boolean,
      mysale:Boolean,
      addr:String,
      addrDetail:String
  });
</script>
<template>
  <div class="state_box">
    <div class="top_row flex_both_ends">
        <strong>{{title}}</strong>
        <span class="date">{{date}}</span>
    </div>
    <div class="mid_row none" v-if="none">
        <strong class="f_red">중개사가 아직 중개의뢰를 수락하지 않았습니다.</strong>
    </div>
    <div class="mid_row flex_both_ends" v-else> 
      <strong class="name">{{info}}</strong>
      <button class="f_blue">중개사 통화<span class="link_arr">아이콘</span></button>
    </div>
    <div class="state_row" v-if="state">
        <ul>
          <li>추천매물:<span class="f_blue">{{num1}}</span></li>
          <li>방문요청:<span class="f_blue">{{num2}}</span></li>
          <li>협의완료:<span class="f_blue">{{num3}}</span></li>
          <li>방문완료:<span class="f_blue">{{num4}}</span></li>
        </ul>
    </div>
    <div class="bottom_row flex_both_ends" v-if="mysale">
      <span>방문예정일: <span class="f_red">{{visit}}</span></span>
      <button v-if="btn" class="btn_round emerald bg">중개 현황</button>
    </div>
    <div class="bottom_row flex_both_ends" v-else>
      <span>{{addr}} <span class="f_red">{{addrDetail}}</span></span>
      <button v-if="btn" class="btn_round emerald bg">중개 현황</button>
    </div>
  </div>
</template>