import { createRouter, createWebHashHistory } from 'vue-router'
import Main from '../user/Main.vue'

const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    {
      path: '/',
      name: 'main',
      component: Main,
    },
    {
      path: '/favOffer',
      name: 'favOffer',
      component: () => import('../offerings/FavOffer.vue')
    },
    {
      path: '/rcnOffer',
      name: 'rcnOffer',
      component: () => import('../offerings/RecntOffer.vue')
    },
    {
      path: '/schOffer',
      name: 'schvOffer',
      component: () => import('../offerings/SchOffer.vue')
    },
    {
      path: '/brokerState',
      name: 'brokerState',
      component: () => import('../brokerState/Index.vue')
    },
    {
      path: '/alarm',
      name: 'alarm',
      component: () => import('../member/Alarm.vue')
    },
    {
      path: '/myhome',
      name: 'myhome',
      component: () => import('../user/Myhome.vue')
    },
    {
      path: '/notice',
      name: 'notice',
      component: () => import('../member/Notice.vue')
    },
    {
      path: '/qna',
      name: 'qna',
      component: () => import('../member/Qna.vue')
    },
    {
      path: '/qnaWrite',
      name: 'qnaWrite',
      component: () => import('../member/QnaWrite.vue')
    },
    {
      path: '/openEvent',
      name: 'openEvent',
      component: () => import('../member/OpenEvent.vue')
    },
    {
      path: '/mngReq',
      name: 'mngReq',
      component: () => import('../member/ManageReq.vue')
    },
    {
      path: '/point',
      name: 'point',
      component: () => import('../member/Point.vue')
    },
    {
      path: '/reqHistory1',
      name: 'reqHistory1',
      component: () => import('../member/ReqHistory1.vue')
    },
    {
      path: '/reqHistory2',
      name: 'reqHistory2',
      component: () => import('../member/ReqHistory2.vue')
    },
    {
      path: '/fee',
      name: 'fee',
      component: () => import('../member/Fee.vue')
    },
  ],
  scrollBehavior (to, from, savedPosition) {
    // savedPosition은 브라우저의 "뒤로 가기" 버튼을 클릭할 때 저장된 위치를 반환합니다.
    if (savedPosition) {
      return savedPosition
    } else {
      return { x: 0, y: 0 }
    }
  }
  
});

export default router
