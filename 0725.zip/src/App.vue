<script setup>
import { useRoute, RouterView } from 'vue-router'
import Footer from './common/Footer.vue'

const route = useRoute()
</script>

<template>
  <div>
    <RouterView />
    <Footer />
  </div>
</template>

<style scoped>

</style>
