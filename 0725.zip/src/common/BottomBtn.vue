<script setup>
  import { defineProps } from 'vue';
  import { useRouter } from 'vue-router';
  const props = defineProps({
    btnTxt1: String,
    btnTxt2:String,
    addClass:String,
    link1:String,
    link2:String
  });
  const router = useRouter();
  
  const navigate1 = () => {
    if (props.link1) {
      router.push(`/${props.link1}`);
    }
  };

  const navigate2 = () => {
    if (props.link2) {
      router.push(`/${props.link2}`);
    }
  };
</script>
<template>
    <div :class="[addClass, 'bottom_btn']">
      <button @click.prevent="navigate1">{{btnTxt1}}</button>
      <button @click.prevent="navigate2" v-if="btnTxt2">{{btnTxt2}}</button>
  </div>
</template>
