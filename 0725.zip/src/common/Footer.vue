<script setup>
  import './common.css'
</script>
<template>
  <div class="footer">
     <ul class="footer_in">
        <li class="home"><RouterLink to="/">홈</RouterLink></li>
        <li class="map"><RouterLink to="/schOffer">지도</RouterLink></li>
        <li class="state"><RouterLink to="/brokerState">중개현황</RouterLink></li>
        <li class="alarm"><RouterLink to="/alarm"><span class="num">4</span>알림</RouterLink></li>
        <li class="more"><RouterLink to="/myhome">더보기</RouterLink></li>
     </ul>
  </div>
</template>
