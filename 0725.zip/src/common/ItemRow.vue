<script setup>
   import { defineProps } from 'vue';
  const props = defineProps({
      wrapClass:String,
      addClass1:String,
      addClass2:String,
      text1:String,
      text2:String,
  });
</script>
<template>
  <div :class="[wrapClass, 'item_row']">
    <div :class="addClass1" v-html="text1"></div>
    <span :class="addClass2" v-html="text2"></span>
</div>
</template>