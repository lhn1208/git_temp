<script setup>
import './member.css'
import { Swiper, SwiperSlide } from 'swiper/vue';
import { ref } from 'vue';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import Header from '../common/Header.vue'
import ItemRow from '../common/ItemRow.vue'
import BottomBtn from '../common/BottomBtn.vue'

const slides =  ['참가 현황', '보낸 추천', '받은 추천'];
const swiperTabs = ref(null);
const swiperContent = ref(null);
const activeIndex = ref(0);  // 현재 활성화된 슬라이드 인덱스

// Swiper 인스턴스를 초기화하고 ref 변수에 할당
const onSwiperTabsInit = (swiper) => {
  swiperTabs.value = swiper;
};
const onSwiperContentInit = (swiper) => {
  swiperContent.value = swiper;
};
// 탭 Swiper가 슬라이드될 때 호출되는 함수
const onTabSlideChange = (swiper) => {
   activeIndex.value = swiper.activeIndex;  // 활성화된 인덱스 업데이트
  swiperContent.value.slideTo(swiper.activeIndex);
};

const onContentSlideChange = (swiper) => {
  activeIndex.value = swiper.activeIndex;  // 활성화된 인덱스 업데이트
  swiperTabs.value.slideTo(swiper.activeIndex);
};

const goToSlide = (index) => {
  activeIndex.value = index;  // 활성화된 인덱스 업데이트
  swiperTabs.value.slideTo(index);
  swiperContent.value.slideTo(index);
};

</script>
<template>
  <div class="open_ev">
   <Header title="오픈 추천 이벤트" link="/" />
   <div class="content_w">
        <div class="box_wrap">
            <div class="box flex_both_ends">
                <strong class="tit">총 추천: <em class="f_red">42</em>개</strong>
                <div class="state">
                    <strong>보낸 추천:<em class="f_red">21</em>개</strong>
                    <strong>받은 추천:<em class="f_red">21</em>개</strong>
                </div>
            </div>
            <div class="box_bottom">
                <div class="flex_both_ends">
                    <strong>현재순위: <em class="f_red">4</em>등(1,000위)</strong>
                    <span>남은 시간: <span class="f_blue">5일 4시간 30분</span></span>
                </div>
            </div>
        </div>
    </div>
   <div>
      <div class="swiper_wrap">
        <!-- 탭 swiper-->
        <Swiper
          class="swiper_header"
          :slidesPerView="3"
          @slideChange="onTabSlideChange"
          @swiper="onSwiperTabsInit"
        >
          <SwiperSlide v-for="(slide, index) in slides" 
            :key="index" 
            :class="{ active: activeIndex === index }"  
            @click="goToSlide(index)"
          >
            {{ slide }}
          </SwiperSlide>
        </Swiper>
      </div>
    </div>
    <div class="">
      <Swiper
        class="swiper"
        :slidesPerView="1"
        @slideChange="onContentSlideChange"
        @swiper="onSwiperContentInit"
      >
        <SwiperSlide>
            <header class="cont_header item_row h55">
                총 참가자
                <span>2,000,000명</span>
            </header>
            <div class="items_wrap">
                <ItemRow 
                    addClass1="f_red"
                    text1="1등"
                    addClass2="f_blue"
                    text2="500만원"
                />
                <ItemRow 
                    text1="10명(1~-10위)"
                    text2="총 5,000만원"
                />
                <ItemRow 
                    text1="현재 10위"
                    text2="추천 수: <span class='f_red'>330</span>개"
                />
            </div>
            <div class="items_wrap">
                <ItemRow 
                    addClass1="f_red"
                    text1="2등"
                    addClass2="f_blue"
                    text2="100만원"
                />
                <ItemRow 
                    text1="50명(11~-60위)"
                    text2="총 5,000만원"
                />
                <ItemRow 
                    text1="현재 60위"
                    text2="추천 수: <span class='f_red'>211</span>개"
                />
            </div>
            <div class="items_wrap">
                <ItemRow 
                    addClass1="f_red"
                    text1="3등"
                    addClass2="f_blue"
                    text2="50만원"
                />
                <ItemRow 
                    text1="500명(61~-560위)"
                    text2="총 25,000만원"
                />
                <ItemRow 
                    text1="현재 560위"
                    text2="추천 수: <span class='f_red'>330</span>개"
                />
            </div>      
        </SwiperSlide>
        <SwiperSlide>
            <header class="item_row h55 info">
                ※ 홍길동님이 보낸 추천을 확인한 분만 나타납니다.
            </header>
            <ItemRow 
                addClass2="date"
                text1="김길남(010-****-0000)"
                text2="23.06.09 14:30"
            />
            <ItemRow 
                addClass2="date"
                text1="김길남(010-****-0000)"
                text2="23.06.09 14:30"
            />
            <ItemRow 
                addClass2="date"
                text1="김길남(010-****-0000)"
                text2="23.06.09 14:30"
            />
        </SwiperSlide>
        <SwiperSlide>
            <header class="item_row info h55">
                ※ 홍길동님이 받은 추천 중 추천 확인한 분만 나타납니다.
            </header>
            <ItemRow 
                addClass2="date"
                text1="김길남(010-****-0000)"
                text2="23.06.09 14:30"
            />
        </SwiperSlide>
      </Swiper>
    </div>
    <BottomBtn btnTxt1="추천하기" />
  </div>
</template>