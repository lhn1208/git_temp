<script setup>
import './member.css'
import Header from '../common/Header.vue'
import ItemRow from '../common/ItemRow.vue'
import BottomBtn from '../common/BottomBtn.vue'
</script>
<template>
<div>
    <Header title="관리요청 내역" link="mngReq" />
    <div class="sub_content">
        <div class="req_history">
            <ItemRow 
                wrapClass="flex_both_ends" 
                text1="<h2>매수/임차 중개의뢰 관리요청</h2>" 
                addClass1="f_red"
                text2="23.07.20"
                addClass2="date"
            />
            <div class="cont_box">
                <strong class="block req_tit">월세 아파트, 단독주택, 다가구주택</strong>
                <ul class="req_list">
                    <li><strong>담당 의뢰인:</strong> <span>홍길동 010-****-000</span></li>
                    <li><strong>기타 의뢰인:</strong> <span>홍길남 010-****-000/홍길녀 010-****-000</span></li>
                    <li><strong>중개사:</strong> <span>홍길동 010-0000-000(은성공인중개사사무소)</span></li>
                </ul>
            </div>
            <ItemRow text1="관리요청인: 홍길남 010-000-0000" addClass1="mid_row"/>
            <div class="cont_box info_box">
                위의 관리요청은 <span class="f_red">매도/임대 또는 매수/임차 중개의뢰에 담당 의뢰인이 의뢰인추가</span>를 하거나, <span class="f_red">중개사가 의뢰인을 등록할 
                    경우 동일한 휴대전화번호를 등록한 고객에게 온라인관리가 요청</span>됩니다.
                <br> <span class="f_red">의뢰인 </span>또는 <span class="f_red">중개사가 실수</span>로 휴대전화번호를 잘못 입력했거나 변경 전화번호를 입력했을 경우 [관리요청 거절]하십시오.        
            </div>
        </div>
        <BottomBtn btnTxt1="관리요청 거절" btnTxt2="관리요청 수락" addClass="col2"/>
    </div>
</div>
</template>
