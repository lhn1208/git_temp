<script setup>
 import Header from '../common/Header.vue'
 import ItemRow from '../common/ItemRow.vue';
 import { useRouter } from 'vue-router';
 import './member.css'
const router = useRouter();
  const navigate = (link) => {
   if(link==='req1'){
    router.push(`/reqHistory1`);
   }else{
    router.push(`/reqHistory2`);
  }
};
</script>
<template>
    <div class="mng_req">
        <Header title="중개의뢰 관리요청" link="myhome" />
        <div class="item_wrap">
            <ItemRow text1="매수/임차 관리요청" addClass1="f_red" />
            <ItemRow text1="월세 | 아파트, 단독주택" />
            <div class="item_row h55 cont_bottom">
                <span>요청일 23.09.09</span>
                <button class="btn_round bg grass" @click.prevent="navigate('req1')">요청확인</button>     
            </div>
        </div>
        <div class="item_wrap">
            <ItemRow text1="매도/임대 관리요청" addClass1="f_blue" />
            <ItemRow text1="월세 | 아파트 서울시 송파구 잠실동 215 102호" />
            <div class="item_row h55 cont_bottom">
                <span>요청일 23.09.01</span>
                <button class="btn_round bg grass" @click.prevent="navigate">요청확인</button>                
            </div>
        </div>
        
    </div>
</template>
