<script setup>
 import Header from '../common/Header.vue'
 import BottomBtn from '../common/BottomBtn.vue' 
  import './member.css'
</script>
<template>
    <div class="sub_content point">
        <Header title="중개수수료 결제" link="myhome" />
        <div class="content_w">
            <div class="point_box">
                <h3>포인트</h3>
                <div class="point_mount"><span class="f_blue">1,000,000</span>원</div>
            </div>
        </div>
        <div class="item_wrap">
            <header class="cont_header item_row"><strong>결제 금액</strong></header>
            <div class="fee_pay">
                <div><input type="text" id="" class="input_amt" value="0" disabled=""> 만원</div>
                <button class="control up"><span class="screen_out">금액 올리기 버튼</span></button>
                <button class="control down"><span class="screen_out">금액 내리기 버튼</span></button>
            </div>
            <div class="item_row bg_pink">
                ※ 결제 금액은 10만원 단위로 최대 100만원까지 가능합니다.
            </div>
            <header class="cont_header item_row"><strong>중개사 선택</strong></header>
            <div class="cont_box">
                <div class="flex_both_ends">
                    <div>
                        홍길동 010-0000-0000
                        <p>잠실제일공인중개사사무소</p>
                    </div>
                    <button class="bg btn_square red">선택</button>
                </div>
            </div>
            <div class="cont_box">
                <div class="flex_both_ends">
                    <div>
                        홍길동 010-0000-0000
                        <p>잠실제일공인중개사사무소</p>
                    </div>
                    <button class="btn_square basic">선택</button>
                </div>
            </div>
        </div>
        <BottomBtn btnTxt1="취소" link1="myhome" btnTxt2="수수료 결제" addClass="col2"/>
    </div>
</template>
