<script setup>
import './member.css'
import Header from '../common/Header.vue'
import QnaItem from './QnaItem.vue'
import BottomBtn from '../common/BottomBtn.vue'

import { useRouter } from 'vue-router';
const router = useRouter();

</script>
<template>
<div class="qna sub_content">
  <Header title="1:1 문의" link="myhome" />
  <QnaItem 
    title="문의제목이 나타납니다"
    rdText="미답변"
    date="23.10.10"
    text="문의 내용입니다.
        <br>문의 내용입니다.
        <br>문의 내용입니다.
        <br>문의 내용입니다."
  />
  <QnaItem 
    title="문의제목이 나타납니다2"
    addClass="grass"
    rdText="답변완료"
    date="23.09.30"
    text="문의 내용입니다.2
        <br>문의 내용입니다.2
        <br>문의 내용입니다.2
        <br>문의 내용입니다.2"
  />
  <BottomBtn btnTxt1="문의하기" link1="qnaWrite"/>
</div>
</template>