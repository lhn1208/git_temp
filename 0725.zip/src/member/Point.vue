<script setup>
 import Header from '../common/Header.vue'
 import ItemRow from '../common/ItemRow.vue';
  import './member.css'
</script>
<template>
    <div class="sub_content point">
        <Header title="포인트" link="myhome" />
        <div class="content_w">
            <div class="point_box">
                <h3>포인트</h3>
                <div class="point_mount"><span class="f_blue">1,000,000</span>원</div>
            </div>
        </div>
        <div class="item_wrap">
            <header class="cont_header item_row h55"><strong>포인트 내역</strong></header>
            <div class="cont_box">
                <div class="flex_both_ends">
                    수수료 결제(김길동-은성공인중개사무소)
                    <span class="date">23.08.08</span>
                </div>
                <div class="flex_both_ends">
                    <span class="f_red">200,000원</span>
                    <span>100,000원</span>
                </div>
            </div>
            <div class="cont_box">
                <div class="flex_both_ends">
                    수수료 결제(김길동-은성공인중개사무소)
                    <span class="date">23.08.01</span>
                </div>
                <div class="flex_both_ends">
                    <span class="f_blue">200,000원</span>
                    <span>300,000원</span>
                </div>
            </div>
        </div>
    
    </div>
</template>
