<script setup>
import './member.css'
import Header from '../common/Header.vue'
import BottomBtn from '../common/BottomBtn.vue'

</script>
<template>
<div class="qna sub_content">
  <Header title="1:1 문의" link="qna" />
  <div class="qna_form">
    <input type="text" class="input" title="제목을 입력하세요" placeholder="제목을 입력하세요">
    <textarea class="textarea" title="내용을 입력하세요" placeholder="내용을 입력하세요"></textarea>
  </div>
  
  <BottomBtn addClass="col2" btnTxt1="취소" btnTxt2="등록" link1=qna link2=myhome />

</div>
</template>