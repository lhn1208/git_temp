<script setup>
  import { defineProps } from 'vue';
  const props = defineProps({
      title:String,
      date:String,
      icoNew:Boolean,
      text:String,
  });
</script>
<template>
  <div class="alarm_box cont_box">
      <div class="flex gap10"><strong class="title">{{title}}</strong><span class="date">{{date}}</span><span class="rd_ico" v-if="icoNew">new</span></div>
      <p class="text">{{text}}</p>
  </div>
</template>