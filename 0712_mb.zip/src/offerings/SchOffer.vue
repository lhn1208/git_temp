<script setup>
import './offerings.css'
import Header from '../common/Header.vue'
import ItemBox from '../components/ItemBox.vue'
import {onMounted, onUnmounted} from 'vue';
onMounted(() => {
    // 페이지가 로드된 후에 실행되는 부분
    document.body.classList.add('hidden-overflow');
});
onUnmounted(() => {
    // 컴포넌트가 파괴될 때 실행되는 부분
    document.body.classList.remove('hidden-overflow');
});
</script>
<template>
    <div class="offerings_sch h100">
        <Header title="서울시 송파구 잠실동" link="/" :btnSch="true"/>
        <div class="sub_header offer_sch_h">
            <div class="info_offer">월세 | 아파트, 단독주택, 다가구주택 <span>+2</span></div>
            <div class="filter_box">필터 <span class="f_red">+3</span></div>
        </div>
        <div class="map">
            <img src="@/assets/images/sub/sample/map.jpg">
        </div>
        <div class="pop_offer">
            <button class="pop_slide_header bg_arr">
                서울시 매물(<em class="f_red">1</em>)
            </button>
            <div class="items_wrap">
                <ItemBox 
                    alt="매물 이미지1" 
                    title="월세 5억1000/50" 
                    info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
                    type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
                    addr="잠실주공1단지 104동잠실"
                    :dealEnd="true"
                />
                <ItemBox 
                    alt="매물 이미지1" 
                    title="월세 5억1000/50" 
                    info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
                    type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
                    addr="잠실주공1단지 104동잠실"
                />
                <ItemBox 
                    alt="매물 이미지1" 
                    title="월세 5억1000/50" 
                    info="3룸 | 3층 | 82㎡(25)/100㎡(33)" 
                    type="아파트" :labels="{label1:'욕실수리', label2:'도배'}"  
                    addr="잠실주공1단지 104동잠실"
                />
            </div>
        </div>
        
    </div>
</template>