import { createRouter, createWebHashHistory } from 'vue-router'
import Main from '../user/Main.vue'

const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    {
      path: '/',
      name: 'main',
      component: Main,
    },
    {
      path: '/favOffer',
      name: 'favOffer',
      component: () => import('../offerings/FavOffer.vue')
    },
    {
      path: '/schOffer',
      name: 'schvOffer',
      component: () => import('../offerings/SchOffer.vue')
    },
  ],
  scrollBehavior (to, from, savedPosition) {
    // savedPosition은 브라우저의 "뒤로 가기" 버튼을 클릭할 때 저장된 위치를 반환합니다.
    if (savedPosition) {
      return savedPosition
    } else {
      return { x: 0, y: 0 }
    }
  }
  
});

export default router
